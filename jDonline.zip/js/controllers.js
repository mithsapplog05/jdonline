angular.module('app.controllers', [])
  
.controller('cameraTabDefaultPageCtrl', function($scope) {

})
   
.controller('cartTabDefaultPageCtrl', function($scope) {

})
   
.controller('cloudTabDefaultPageCtrl', function($scope) {

})
         
.controller('categoriesCtrl', function($scope) {

})
   
.controller('automobilesCtrl', function($scope) {

})
   
.controller('whatIsJDOnlineCtrl', function($scope) {

})
   
.controller('contactUSCtrl', function($scope) {

})
   
.controller('profileCtrl', function($scope) {

})
   
.controller('loginCtrl', function($scope) {

})
 